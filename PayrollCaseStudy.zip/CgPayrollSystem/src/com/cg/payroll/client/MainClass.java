package com.cg.payroll.client;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailNotfoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass {
	public static void main(String[] args) {
		PayrollServices services=new PayrollServicesImpl();
		int associateId=services.acceptAssociateDetails("Shradha", "Roy", "shradha.roy@gmail.com", "YTP", "CEO", "2323", 50000, 300000, 12000, 12000, 7888,"CITIBANK","ABCD1234");
		System.out.println("Associate Id "+associateId);
		try {
			System.out.println("Net Annual Salary---->"+services.calculateNetSalary(associateId));
			System.out.println("Net Monthly Salary---->"+(services.calculateNetSalary(associateId))/12);
		} catch (AssociateDetailNotfoundException e) {
			
			e.printStackTrace();
		}
		}
}
