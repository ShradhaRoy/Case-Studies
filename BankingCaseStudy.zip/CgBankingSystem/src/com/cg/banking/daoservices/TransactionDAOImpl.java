package com.cg.banking.daoservices;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.bankig.beans.Transaction;
import com.cg.banking.util.AccountDBUtil;



public class TransactionDAOImpl implements TransactionDAO{

	@Override
	public Transaction save(long accountNo,Transaction transaction) {
		transaction.setTransactionId(AccountDBUtil.generateTRANSACTION_ID());
		AccountDBUtil.customerAccountDetails.get(accountNo).getTransactions().put(transaction.getTransactionId(),transaction);
		return transaction;
	}

	@Override
	public boolean update(long accountNo,Transaction transaction) {
		return false;
	}

	@Override
	public Transaction findOne(long accountNo,int transactionId) {
		return AccountDBUtil.customerAccountDetails.get(accountNo).getTransactions().get(transactionId);
	}

	@Override
	public List<Transaction> findAll(long accountNo) {
		
		return new ArrayList<Transaction>(AccountDBUtil.customerAccountDetails.get(accountNo).getTransactions().values());
	}

	

}
