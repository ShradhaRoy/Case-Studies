package com.cg.banking.util;

import java.util.HashMap;

import com.cg.bankig.beans.Account;

public class AccountDBUtil {
public static HashMap<Long, Account> customerAccountDetails=new HashMap<>();
	private static long ACCOUNT_NUMBER=100000;
	private static int TRANSACTION_NUMBER=100;
	
	public static long getACCOUNT_NUMBER() {
		return ++ACCOUNT_NUMBER;
}
	public static int generateTRANSACTION_ID() {
		return ++TRANSACTION_NUMBER;
	}

}
